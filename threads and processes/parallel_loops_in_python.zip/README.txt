Parallel Loops in Python
========================

README
------

Welcome to Parallel Loops in Python!

Your package contains:

1. README (this file)
	README.txt
2. Ebook
	parallel_loops_in_python.pdf
	parallel_loops_in_python.epub
3. Code
	src/*.py

If you need help sending the ebook to your kindle, see:

* Send to kindle
  https://www.amazon.com/gp/sendtokindle

If you need help adding the ebook to iBooks, see:

* Import books, audiobooks or PDFs in Books on Mac
  https://support.apple.com/en-au/guide/books/ibkseed72068/mac

Any questions at all, contact me directly via:
https://SuperFastPython.com/contact/


Kind Regards,

Jason Brownlee.
SuperFastPython.com
