#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

def function(n):
    print(n)

function(47)
