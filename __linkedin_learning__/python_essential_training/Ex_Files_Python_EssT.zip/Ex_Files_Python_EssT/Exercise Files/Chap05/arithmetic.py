#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

x = 5
y = 3
z = x + y

print(f'result is {z}')
